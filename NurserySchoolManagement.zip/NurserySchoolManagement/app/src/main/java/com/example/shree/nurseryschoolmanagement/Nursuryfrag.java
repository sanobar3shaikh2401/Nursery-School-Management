package com.example.shree.nurseryschoolmanagement;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class Nursuryfrag extends Fragment {
    View view;
    ListView lst_stud;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.nursuryfrag,null);
        lst_stud=(ListView) view.findViewById(R.id.lst_stud);
        Studisplay.obj.clear();
        RequestQueue q= Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req=new JsonArrayRequest("http://192.168.43.211/NSM/Studentdisplay.php?classtype=Nursery", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int count = response.length();
                Studisplay.obj.clear();
                for(int i=0;i<count;i++)
                {
                    try{

                        JSONObject obj=response.getJSONObject(i);
                        Studisplay s=new Studisplay();
                        s.setRn(obj.getString("Rollno"));
                        s.setNm(obj.getString("Name"));
                        s.setAdd(obj.getString("Address"));
                        s.setPhno(obj.getString("Phone_no"));

                        s.setEmail(obj.getString("Email"));
                        s.setDoa(obj.getString("DOA"));
                        Studisplay.obj.add(s);
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }

                StudAdapter adp=new StudAdapter(getActivity().getApplicationContext());
                lst_stud.setAdapter(adp);
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        }

        );
        q.add(req);
        /*StudAdapter adapter = new StudAdapter(getActivity().getApplicationContext());
        lst_stud.setAdapter(adapter);*/
        return view;
    }
    @Override
    public void onResume() {
        RequestQueue q= Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req=new JsonArrayRequest("http://192.168.43.211/NSM/Studentdisplay.php?classtype=Nursery", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int count = response.length();
                Studisplay.obj.clear();
                for(int i=0;i<count;i++)
                {
                    try{

                        JSONObject obj=response.getJSONObject(i);
                        Studisplay s=new Studisplay();
                        s.setRn(obj.getString("Rollno"));
                        s.setNm(obj.getString("Name"));
                        s.setAdd(obj.getString("Address"));
                        s.setPhno(obj.getString("Phone_no"));

                        s.setEmail(obj.getString("Email"));
                        s.setDoa(obj.getString("DOA"));
                        Studisplay.obj.add(s);
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }

                StudAdapter adp=new StudAdapter(getActivity().getApplicationContext());
                lst_stud.setAdapter(adp);
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        }

        );
        q.add(req);
        super.onResume();

    }
}
