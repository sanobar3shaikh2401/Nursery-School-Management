package com.example.shree.nurseryschoolmanagement;

import java.util.ArrayList;

public class eventdisplay {
    String name,Sdate,Edate,des;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSdate() {
        return Sdate;
    }

    public void setSdate(String sdate) {
        Sdate = sdate;
    }

    public String getEdate() {
        return Edate;
    }

    public void setEdate(String edate) {
        Edate = edate;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
    public static ArrayList<eventdisplay> obj=new ArrayList<eventdisplay>();
}
