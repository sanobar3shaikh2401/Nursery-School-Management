package com.example.shree.nurseryschoolmanagement;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class studLKGadptr extends BaseAdapter {
    Context context;
    LayoutInflater inflate;
    public studLKGadptr(Context context) {
        this.context = context;
    }
    @Override
    public int getCount() {
        return StuddisplayLKG.obj.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        inflate= LayoutInflater.from(context);
        view = inflate.inflate(R.layout.adapter_stud,null);
        TextView t1=(TextView) view.findViewById(R.id.txt_rn);
        TextView t2=(TextView) view.findViewById(R.id.txt_nm);
        TextView t3=(TextView) view.findViewById(R.id.txt_add);
        TextView t4=(TextView) view.findViewById(R.id.txt_ph);
        // TextView t5=(TextView) view.findViewById(R.id.txt_cls);
        TextView t6=(TextView) view.findViewById(R.id.txt_email);
        TextView t7=(TextView) view.findViewById(R.id.txt_doa);
        t1.setText(StuddisplayLKG.obj.get(i).getRn());
        t2.setText(StuddisplayLKG.obj.get(i).getNm());
        t3.setText(StuddisplayLKG.obj.get(i).getAdd());
        t4.setText(StuddisplayLKG.obj.get(i).getPhno());
        t6.setText(StuddisplayLKG.obj.get(i).getEmail());
        t7.setText(StuddisplayLKG.obj.get(i).getDoa());
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent studIntent = new Intent(context,StudentActivity.class);
                studIntent.putExtra("roll",StuddisplayLKG.obj.get(i).getRn());
                studIntent.putExtra("position",""+i);
                studIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(studIntent);
            }
        });
        final View finalConvertView = view;
        view.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(finalConvertView.getRootView().getContext());
                dialog.setMessage("Delete Record");
                dialog.setTitle("Deleting Student");
                dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        RequestQueue q = Volley.newRequestQueue(context);
                        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Studentdelete.php?rn="+StuddisplayLKG.obj.get(i).getRn(), new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                if (response.length() > 0) {
                                    try {
                                        JSONObject obj = response.getJSONObject(0);
                                        String msg = obj.getString("msg");
                                        if (msg.equalsIgnoreCase("Deleted")) {
                                            StuddisplayLKG.obj.remove(i);
                                            notifyDataSetChanged();
                                            Toast.makeText(context, "Data deleted", Toast.LENGTH_LONG).show();
                                        } else {
                                            Toast.makeText(context, "Not Deleted", Toast.LENGTH_LONG).show();
                                        }
                                    } catch (Exception e) {

                                    }
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                            }
                        });
                        q.add(req);
                    }
                });
                dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"Record delete Canceled",Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog alert=dialog.create();
                alert.show();
                return true;
            }
        });


        return view;
    }
}
