package com.example.shree.nurseryschoolmanagement;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class LKGhwfrag extends Fragment {
    View view;
    ListView lst_hw;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.lkghwfrag,null);
        lst_hw=(ListView)view.findViewById(R.id.lst_hw);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Homeworkdisplay.php?classtype=LKG", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                Homeworkdisplay.obj.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        Homeworkdisplay t = new Homeworkdisplay();
                        t.setId(jobj.getString("id"));
                        t.setDate(jobj.getString("Date"));
                        t.setHw(jobj.getString("Homework"));
                        t.setTid(jobj.getString("Teacherid"));
                        t.setSub(jobj.getString("Subject"));
                        Homeworkdisplay.obj.add(t);
                        // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                Homeworkadapter hadp = new Homeworkadapter(getActivity().getApplicationContext());
                lst_hw.setAdapter(hadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(req);

        return view;
    }
    @Override
    public void onResume() {
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Homeworkdisplay.php?classtype=LKG", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                Homeworkdisplay.obj.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        Homeworkdisplay t = new Homeworkdisplay();
                        t.setId(jobj.getString("id"));
                        t.setDate(jobj.getString("Date"));
                        t.setHw(jobj.getString("Homework"));
                        t.setTid(jobj.getString("Teacherid"));
                        t.setSub(jobj.getString("Subject"));
                        Homeworkdisplay.obj.add(t);
                        // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                Homeworkadapter hadp = new Homeworkadapter(getActivity().getApplicationContext());
                lst_hw.setAdapter(hadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(req);

        super.onResume();

    }
}
