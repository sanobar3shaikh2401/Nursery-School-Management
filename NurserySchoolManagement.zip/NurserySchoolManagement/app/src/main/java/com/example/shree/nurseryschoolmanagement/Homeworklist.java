package com.example.shree.nurseryschoolmanagement;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class Homeworklist extends FragmentStatePagerAdapter {
    String title[]={"Nursery","LKG","UKG"};
    int count;
    public Homeworklist(FragmentManager fm,int count){
        super(fm);
        this.count=count;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return title[position];
    }

    @Override

    public Fragment getItem(int position) {
        switch (position) {
            case 0:Nurseryhwfrag nur=new Nurseryhwfrag();
            return nur;
            case 1:LKGhwfrag lkg=new LKGhwfrag();
            return lkg;
            case 2:UKGhwfrag ukg=new UKGhwfrag();
            return ukg;
        }
        return null;
    }

    @Override

    public int getCount() {
        return count;
    }
}
