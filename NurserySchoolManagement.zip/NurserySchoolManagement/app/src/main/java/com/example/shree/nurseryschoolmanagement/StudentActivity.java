package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class StudentActivity extends AppCompatActivity {
    Spinner spnr_std;
    EditText e1,e2,e3,e4,e5,e6;
    Button b1;
    String std[]={"SELECT CLASS","Nursery","LKG","UKG"};
    String roll=null;
    int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        e1=(EditText)findViewById(R.id.edt_sroll);
        e2=(EditText)findViewById(R.id.edt_snm);
        e3=(EditText)findViewById(R.id.edt_add);
        e4=(EditText)findViewById(R.id.edt_spno);
        e5=(EditText)findViewById(R.id.edt_semail);
        e6=(EditText)findViewById(R.id.edt_sdoa);
        b1=(Button)findViewById(R.id.btn_reg);
        spnr_std=(Spinner)findViewById(R.id.spnr_std);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getApplicationContext(),R.layout.list_item,std);
        spnr_std.setAdapter(adapter1);
        try{
            Intent tmp = getIntent();
            roll = tmp.getStringExtra("roll");
            position=Integer.parseInt(tmp.getStringExtra("position"));
            fetchStudInfo();
        }catch (Exception e){

        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(roll==null) {
                    RequestQueue q = Volley.newRequestQueue(getApplicationContext());
                    JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/StudentInsertapi.php?nm=" + e2.getText().toString() + "&add=" + e3.getText().toString() + "&mob=" + e4.getText().toString() + "&class=" + spnr_std.getSelectedItem().toString() + "&email=" + e5.getText().toString() + "&doa=" + e6.getText().toString(), new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Data inserted")) {
                                        Toast.makeText(getApplicationContext(), "inserted", Toast.LENGTH_LONG).show();
                                        finish();
                                    } else {
                                        Toast.makeText(getApplicationContext(), "not inserted", Toast.LENGTH_LONG).show();
                                    }
                                } catch (Exception e) {

                                }

                            }


                        }

                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                    );
                    q.add(req);
                }
                else{
                    RequestQueue q = Volley.newRequestQueue(getApplicationContext());
                    JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Studentupdate.php?rn="+roll+"&nm=" + e2.getText().toString() + "&add=" + e3.getText().toString() + "&mob=" + e4.getText().toString() + "&class=" + spnr_std.getSelectedItem().toString() + "&email=" + e5.getText().toString() + "&doa=" + e6.getText().toString(), new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Updated")) {
                                        Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                                        StuddisplayLKG.obj.get(position).setNm(e2.getText().toString());
                                        StuddisplayLKG.obj.get(position).setAdd(e3.getText().toString());
                                        StuddisplayLKG.obj.get(position).setPhno(e4.getText().toString());
                                        StuddisplayLKG.obj.get(position).setEmail(e5.getText().toString());
                                        StuddisplayLKG.obj.get(position).setDoa(e6.getText().toString());
                                        finish();
                                    } else {
                                        Toast.makeText(getApplicationContext(), "not Updated", Toast.LENGTH_LONG).show();

                                    }
                                } catch (Exception e) {

                                }

                            }


                        }

                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                    );
                    q.add(req);
                }


            }
        }

        );





    }

    private void fetchStudInfo() {
        RequestQueue q= Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest req=new JsonArrayRequest("http://192.168.43.211/NSM/Studentdisplay.php?roll="+roll, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int count = response.length();
                //Studisplay.obj.clear();
                for(int i=0;i<count;i++)
                {
                    try{

                        JSONObject obj=response.getJSONObject(i);
                        Studisplay s=new Studisplay();
                        e1.setText(obj.getString("Rollno"));
                        e2.setText(obj.getString("Name"));
                        e3.setText(obj.getString("Address"));
                        e4.setText(obj.getString("Phone_no"));
                        e5.setText(obj.getString("Email"));
                        e6.setText(obj.getString("DOA"));
                        Studisplay.obj.add(s);
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        }

        );
        q.add(req);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
}
}
