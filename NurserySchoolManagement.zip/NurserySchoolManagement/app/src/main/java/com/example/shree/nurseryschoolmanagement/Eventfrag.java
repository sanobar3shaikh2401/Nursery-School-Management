package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.shree.nurseryschoolmanagement.EventActivity;
import com.example.shree.nurseryschoolmanagement.HomeworkActivity;
import com.example.shree.nurseryschoolmanagement.R;

import org.json.JSONArray;
import org.json.JSONObject;

public class Eventfrag extends Fragment {
    View view;
    ListView lst_event;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.studentfrag,null);
        lst_event=(ListView)view.findViewById(R.id.lst_hw);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Eventdisplay.php", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                Homeworkdisplay.obj.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        eventdisplay t = new eventdisplay();
                        t.setName(jobj.getString("Name"));
                        t.setSdate(jobj.getString("Startdate"));
                        t.setEdate(jobj.getString("Enddate"));
                        t.setDes(jobj.getString("Decription"));
                        eventdisplay.obj.add(t);
                        // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                Homeworkadapter hadp = new Homeworkadapter(getActivity().getApplicationContext());
                lst_event.setAdapter(hadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(req);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                Intent std=new Intent(getActivity().getApplicationContext(),EventActivity.class);
                startActivity(std);


            }
        });
        return view;
    }
    @Override
    public void onResume() {
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Eventdisplay.php", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                Homeworkdisplay.obj.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        eventdisplay t = new eventdisplay();
                        t.setName(jobj.getString("Name"));
                        t.setSdate(jobj.getString("Startdate"));
                        t.setEdate(jobj.getString("Enddate"));
                        t.setDes(jobj.getString("Decription"));
                        eventdisplay.obj.add(t);
                        // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                Homeworkadapter hadp = new Homeworkadapter(getActivity().getApplicationContext());
                lst_event.setAdapter(hadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(req);

        super.onResume();

    }
}
