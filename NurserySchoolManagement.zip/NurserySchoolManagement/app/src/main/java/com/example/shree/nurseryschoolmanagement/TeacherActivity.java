package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class TeacherActivity extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5,e6,e7;
    Button b1;
    String id=null;
    int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);
        e1=(EditText)findViewById(R.id.tid);
        e2=(EditText)findViewById(R.id.tname);
        e7=(EditText)findViewById(R.id.tadd);
        e3=(EditText)findViewById(R.id.tpno);
        e4=(EditText)findViewById(R.id.temail);
        e5=(EditText)findViewById(R.id.tuname);
        e6=(EditText)findViewById(R.id.tpass);
        b1=(Button)findViewById(R.id.btn_addt);
        try{
            Intent tmp = getIntent();
            id = tmp.getStringExtra("id");
            position=Integer.parseInt(tmp.getStringExtra("position"));
            fetchStudInfo();
        }catch (Exception e){

        }
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (id == null) {


                    RequestQueue q = Volley.newRequestQueue(getApplicationContext());
                    JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/teacherinsert.php?nm=" + e2.getText().toString() + "&add=" + e7.getText().toString() + "&mob=" + e3.getText().toString() + "&email=" + e4.getText().toString() + "&unm=" + e5.getText().toString() + "&pw=" + e6.getText().toString(), new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Data inserted")) {
                                        Toast.makeText(getApplicationContext(), "inserted", Toast.LENGTH_LONG).show();
                                        finish();
                                    } else {
                                        Toast.makeText(getApplicationContext(), "not inserted", Toast.LENGTH_LONG).show();
                                    }
                                } catch (Exception e) {

                                }

                            }


                        }

                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                 );


                    q.add(req);
                }


             else {
                    RequestQueue q = Volley.newRequestQueue(getApplicationContext());
                    JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/teacherupdate.php?id="+id +"&nm=" + e2.getText().toString() + "&add=" + e7.getText().toString() + "&mob=" + e3.getText().toString() + "&email=" + e4.getText().toString() + "&unm=" + e5.getText().toString() + "&pw=" + e6.getText().toString(), new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Updated")) {
                                        Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                                        TeacherDisp.obj.get(position).setNm(e2.getText().toString());
                                        TeacherDisp.obj.get(position).setAdd(e7.getText().toString());
                                        TeacherDisp.obj.get(position).setPh(e3.getText().toString());
                                        TeacherDisp.obj.get(position).setEmail(e4.getText().toString());
                                        TeacherDisp.obj.get(position).setUnm(e5.getText().toString());
                                        TeacherDisp.obj.get(position).setPass(e6.getText().toString());
                                        finish();
                                    } else {
                                        Toast.makeText(getApplicationContext(), "not Updated", Toast.LENGTH_LONG).show();

                                    }
                                } catch (Exception e) {

                                }

                            }


                        }

                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }

                    );
                    q.add(req);

                }
            }

            });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    private void fetchStudInfo() {
        RequestQueue q= Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest req=new JsonArrayRequest("http://192.168.43.211/NSM/teacherdisplay.php?id="+id, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int count = response.length();
                for(int i=0;i<count;i++)
                {
                    try{

                        JSONObject obj=response.getJSONObject(i);
                        TeacherDisp s=new TeacherDisp();
                        e1.setText(obj.getString("ID"));
                        e2.setText(obj.getString("Name"));
                        e7.setText(obj.getString("Address"));
                        e3.setText(obj.getString("Phone_no"));

                        e4.setText(obj.getString("Email"));
                        e5.setText(obj.getString("Username"));
                        e6.setText(obj.getString("Password"));
                        TeacherDisp.obj.add(s);
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        }

        );
        q.add(req);
    }



            @Override
            public boolean onSupportNavigateUp() {
                finish();
                return super.onSupportNavigateUp();
            }


}