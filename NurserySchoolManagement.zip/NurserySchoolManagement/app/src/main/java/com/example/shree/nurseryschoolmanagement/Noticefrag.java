package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.shree.nurseryschoolmanagement.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class Noticefrag extends Fragment {
    ListView l1;
    View view;
    ArrayList<NoticeDisplay> data;
    NoticeAdapter nadp;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.noticefrag,null);
        l1=(ListView)view.findViewById(R.id.lst_not);
        //l1=(ListView)view.findViewById(R.id.lst_hw);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Noticedisplay.php", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                NoticeDisplay.arr.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        NoticeDisplay t = new NoticeDisplay();
                        t.setDt(jobj.getString("Date"));
                        t.setCls(jobj.getString("Class"));
                        t.setDesc(jobj.getString("Description"));
                        t.setSub(jobj.getString("Subject"));
                        t.setId(jobj.getString("id"));
                        NoticeDisplay.arr.add(t);
                        // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                nadp = new NoticeAdapter(getActivity().getApplicationContext());
                l1.setAdapter(nadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(req);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                Intent std=new Intent(getActivity().getApplicationContext(),NoticeActivity.class);
                startActivity(std);

            }
        });

         FloatingActionButton fab1= (FloatingActionButton) view.findViewById(R.id.fab1);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                  //      .setAction("Action", null).show();
                data = NoticeAdapter.getbox();
                for(int i=0;i<data.size();i++)
                {
                    RequestQueue q = Volley.newRequestQueue(getActivity().getApplicationContext());
                    final int finalI = i;
                    JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Noticedelete.php?id="+data.get(i).getId(), new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Deleted")) {
                                        NoticeDisplay.arr.remove(finalI);
                                        //notifyDataSetChanged();
                                        Toast.makeText(getActivity().getApplicationContext(), "Data deleted", Toast.LENGTH_LONG).show();
                                    } else {
                                        Toast.makeText(getActivity().getApplicationContext(), "Not Deleted", Toast.LENGTH_LONG).show();
                                    }
                                } catch (Exception e) {

                                }
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    });
                    q.add(req);
                    nadp.notifyDataSetChanged();
                    l1.setAdapter(nadp);
                }

            }
        });
        return view;

    }

    @Override
    public void onResume() {
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Noticedisplay.php", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                NoticeDisplay.arr.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        NoticeDisplay t = new NoticeDisplay();
                        t.setDt(jobj.getString("Date"));
                        t.setCls(jobj.getString("Class"));
                        t.setDesc(jobj.getString("Description"));
                        t.setSub(jobj.getString("Subject"));
                        t.setId(jobj.getString("id"));
                        NoticeDisplay.arr.add(t);
                        // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                nadp = new NoticeAdapter(getActivity().getApplicationContext());
                l1.setAdapter(nadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(req);
//        nadp.notifyDataSetChanged();
        super.onResume();

    }
}
