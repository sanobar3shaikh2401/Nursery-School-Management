package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {
    Button b1,b2;
    EditText e1,e2,e3,e4;
    Spinner spnr_role;
    String role[]={"Principal","Teacher","Parent"};
    Spinner spnr_std;
    String std[]={"SELECT CLASS","Nursery","LKG","UKG"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        b1 = (Button) findViewById(R.id.btn_login);
        b2 = (Button) findViewById(R.id.btn_forgotp);
        e1 = (EditText) findViewById(R.id.edt_user);
        e2 = (EditText) findViewById(R.id.edt_pass);
        e3 = (EditText) findViewById(R.id.edt_rollno);
        e4 = (EditText) findViewById(R.id.edt_pno);
        spnr_role = (Spinner) findViewById(R.id.spnr_role);
        spnr_std = (Spinner) findViewById(R.id.spnr_std);
        e1.setVisibility(View.GONE);
        e2.setVisibility(View.GONE);
        b1.setVisibility(View.GONE);
        b2.setVisibility(View.GONE);
        spnr_std.setVisibility(View.GONE);
        e3.setVisibility(View.GONE);
        e4.setVisibility(View.GONE);
        spnr_role.setVisibility(View.VISIBLE);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_item, role);
        spnr_role.setAdapter(adapter);
        spnr_role.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if (i == 0|| i == 1) {

                    e1.setVisibility(View.VISIBLE);
                    e2.setVisibility(View.VISIBLE);
                    b1.setVisibility(View.VISIBLE);
                    b2.setVisibility(View.VISIBLE);
                    spnr_std.setVisibility(View.GONE);
                    e3.setVisibility(View.GONE);
                    e4.setVisibility(View.GONE);
                } else {

                    e1.setVisibility(View.GONE);
                    e2.setVisibility(View.GONE);
                    spnr_std.setVisibility(View.VISIBLE);
                    e3.setVisibility(View.VISIBLE);
                    e4.setVisibility(View.VISIBLE);
                    b1.setVisibility(View.VISIBLE);
                    b2.setVisibility(View.VISIBLE);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spnr_role.setSelection(0);

        spnr_std = (Spinner) findViewById(R.id.spnr_std);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_item, std);
        spnr_std.setAdapter(adapter1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = spnr_role.getSelectedItemPosition();
                switch (pos) {
                    case 0:

                        if (e1.getText().toString().equals("Principal") && e2.getText().toString().equals("Principal")) {
                            Intent obj2 = new Intent(getApplicationContext(), Navigation2Activity.class);

                            finish();
                            startActivity(obj2);
                        } else {
                            Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_LONG).show();

                        }
                        break;

                    case 1:
                      /* if(e1.getText().toString().equals("Teacher") &&e2.getText().toString().equals("Teacher")) {


                       }
                       else{
                           Toast.makeText(getApplicationContext(),"Login Failed",Toast.LENGTH_LONG).show();

                       }*/
                        RequestQueue q = Volley.newRequestQueue(getApplicationContext());
                        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Teacherlogin.php?Username="+e1.getText().toString() + "&Password=" + e2.getText().toString(), new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                if (response.length() > 0) {
                                    try {
                                        JSONObject obj = response.getJSONObject(0);
                                        String msg = obj.getString("msg");
                                        if (msg.equalsIgnoreCase("Login Success")) {
                                            Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_LONG).show();
                                            Userdata.id=obj.getString("ID");
                                            Userdata.name = obj.getString("Name");
                                            Userdata.add=obj.getString("Address");
                                            Userdata.phno=obj.getString("Phone_no");
                                            Userdata.email=obj.getString("Email");
                                            Userdata.unm=obj.getString("Username");
                                            Userdata.pass=obj.getString("Password");
                                            Intent obj1 = new Intent(getApplicationContext(), StandardActivity.class);
                                            finish();
                                            startActivity(obj1);

                                        } else {
                                            Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_LONG).show();
                                        }
                                    } catch (Exception e) {

                                    }
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_LONG).show();

                            }
                        });
                        q.add(req);


                        break;
                    case 2:
                      /*  if (e1.getText().toString().equals("1") && e2.getText().toString().equals("7020404379")) {

                            Intent obj1 = new Intent(getApplicationContext(), ParentActivity.class);
                            finish();
                            startActivity(obj1);
                        } else {
                            Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_LONG).show();

                        }*/
                        RequestQueue q1 = Volley.newRequestQueue(getApplicationContext());
                        JsonArrayRequest req1 = new JsonArrayRequest("http://192.168.43.211/NSM/Parentlogin.php?Rollno="+e3.getText().toString() + "&Phone_no=" + e4.getText().toString(), new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                if (response.length() > 0) {
                                    try {
                                        JSONObject obj = response.getJSONObject(0);
                                        String msg = obj.getString("msg");
                                        if (msg.equalsIgnoreCase("Login Success")) {
                                            Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_LONG).show();
                                            parentdata.rn=obj.getString("Rollno");
                                            parentdata.nm = obj.getString("Name");
                                            parentdata.add=obj.getString("Address");
                                            parentdata.phno=obj.getString("Phone_no");
                                            parentdata.cls=obj.getString("Class");
                                            parentdata.email=obj.getString("Email");
                                            parentdata.doa=obj.getString("DOA");
                                            Intent obj1 = new Intent(getApplicationContext(), ParentActivity.class);
                                            finish();
                                            startActivity(obj1);

                                        } else {
                                            Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_LONG).show();
                                        }
                                    } catch (Exception e) {

                                    }
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Toast.makeText(getApplicationContext(), "Login Failed", Toast.LENGTH_LONG).show();

                            }
                        });
                        q1.add(req1);

                        break;
                    default:
                        Toast.makeText(getApplicationContext(), "wrong choice", Toast.LENGTH_LONG).show();


                }
            }


        });


        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj1=new Intent(getApplicationContext(),ForgotActivity.class);
                finish();
                startActivity(obj1);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
