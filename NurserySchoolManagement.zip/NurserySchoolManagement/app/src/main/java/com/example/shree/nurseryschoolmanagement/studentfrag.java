package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class studentfrag extends Fragment {
    View view;
    TabLayout tabl;

    ViewPager vp;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.studentfrag,null);
        tabl=(TabLayout) view.findViewById(R.id.tab_std);
        vp =(ViewPager) view.findViewById(R.id.view_tab);
        Studentlist adapter = new Studentlist(getActivity().getSupportFragmentManager(),3);
        /*tabl.addTab(tabl.newTab().setText("Nursery"));
        tabl.addTab(tabl.newTab().setText("LKG"));
        tabl.addTab(tabl.newTab().setText("UKG"));
        tabl.setTabGravity(TabLayout.GRAVITY_FILL);*/
        vp.setAdapter(adapter);
        tabl.setupWithViewPager(vp);

        tabl.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                vp.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                Intent std=new Intent(getActivity().getApplicationContext(),StudentActivity.class);
                startActivity(std);


            }
        });
        return view;
    }
    @Override
    public void onResume() {
        super.onResume();

    }
}
