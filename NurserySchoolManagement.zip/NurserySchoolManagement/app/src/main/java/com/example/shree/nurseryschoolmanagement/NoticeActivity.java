package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class NoticeActivity extends AppCompatActivity {
    Spinner spnr_std;
    DatePicker dp;
    EditText e1,e2,e3;
    Button btn;
    String id=null;
    int position;
    String std[]={"SELECT CLASS","Nursery","LKG","UKG"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        e1 = (EditText) findViewById(R.id.edt_sub);
        e2 = (EditText) findViewById(R.id.edt_desp);
        e3=(EditText)findViewById(R.id.edt_id);
        btn = (Button) findViewById(R.id.btn_send);
        dp=(DatePicker)findViewById(R.id._date);
        spnr_std = (Spinner) findViewById(R.id.spnr_ncls);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_item, std);
        spnr_std.setAdapter(adapter1);
        try{
            Intent tmp = getIntent();
            id = tmp.getStringExtra("id");
            position=Integer.parseInt(tmp.getStringExtra("position"));
            fetchStudInfo();
        }catch (Exception e){

        }

        NoticeDisplay.arr.clear();


        btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        if (id == null) {
            RequestQueue q = Volley.newRequestQueue(getApplicationContext());
            JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Noticeinsert.php?date=12-1-19&sub=" + e1.getText().toString() + "&des=" + e2.getText().toString() + "&class=" + spnr_std.getSelectedItem().toString(), new Response.Listener<JSONArray>() {

                @Override
                public void onResponse(JSONArray response) {
                    if (response.length() > 0) {
                        try {
                            JSONObject obj = response.getJSONObject(0);
                            String msg = obj.getString("msg");
                            if (msg.equalsIgnoreCase("Data inserted")) {
                                Toast.makeText(getApplicationContext(), "inserted", Toast.LENGTH_LONG).show();
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "not inserted", Toast.LENGTH_LONG).show();
                            }
                        } catch (Exception e) {

                        }
                    }
                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            );


            q.add(req);
        }
         else {
            RequestQueue q = Volley.newRequestQueue(getApplicationContext());
            JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Noticeupdate.php?id="+id+"&date=12-1-19&sub=" + e1.getText().toString() + "&des=" + e2.getText().toString() + "&class=" + spnr_std.getSelectedItem().toString(),new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    if (response.length() > 0) {
                        try {
                            JSONObject obj = response.getJSONObject(0);
                            String msg = obj.getString("msg");
                            if (msg.equalsIgnoreCase("Updated")) {
                                Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                                NoticeDisplay.arr.get(position).setSub(e1.getText().toString());
                                NoticeDisplay.arr.get(position).setDesc(e2.getText().toString());
                                NoticeDisplay.arr.get(position).setId(e3.getText().toString());
                                NoticeDisplay.arr.get(position).setCls(spnr_std.getSelectedItem().toString());
                               // NoticeDisplay.arr.get(position).setDt(dp.get.toString());
                                finish();
                            } else {
                                Toast.makeText(getApplicationContext(), "not Updated", Toast.LENGTH_LONG).show();

                            }
                        } catch (Exception e) {

                        }

                    }


                }

            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }

            );
            q.add(req);

        }
    }

        });
       // getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
    private void fetchStudInfo() {
        RequestQueue q= Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest req=new JsonArrayRequest("http://192.168.43.211/NSM/Noticedisplay.php?id="+id, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int count = response.length();
                for(int i=0;i<count;i++)
                {
                    try{

                        JSONObject arr=response.getJSONObject(i);
                        NoticeDisplay s=new NoticeDisplay();
                        e3.setText(arr.getString("id"));
                        e2.setText(arr.getString("Description"));
                        e1.setText(arr.getString("Subject"));
                        NoticeDisplay.arr.add(s);
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_LONG).show();
            }
        }

        );
        q.add(req);
    }


@Override
public boolean onSupportNavigateUp() {
        finish();
        return super.onSupportNavigateUp();
        }


        }