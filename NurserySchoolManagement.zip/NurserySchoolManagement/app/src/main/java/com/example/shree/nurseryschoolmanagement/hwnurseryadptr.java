package com.example.shree.nurseryschoolmanagement;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class hwnurseryadptr extends BaseAdapter {
    Context context;
    LayoutInflater inflate;
    public hwnurseryadptr(Context context){
        this.context=context;
    }
    @Override
    public int getCount() {
            return hwnurserydisplay.obj.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        inflate = LayoutInflater.from(context);
        convertView = inflate.inflate(R.layout.hwadptr,null);
        TextView t1 =(TextView) convertView.findViewById(R.id.txt_d);
        TextView t2 =(TextView) convertView.findViewById(R.id.txt_des);
        TextView t3 =(TextView) convertView.findViewById(R.id.txt_tid);
        TextView t4 =(TextView) convertView.findViewById(R.id.txt_sub);
        t1.setText(hwnurserydisplay.obj.get(position).getDate());
        t2.setText(hwnurserydisplay.obj.get(position).getHw());
        t3.setText(hwnurserydisplay.obj.get(position).getTid());
        t4.setText(hwnurserydisplay.obj.get(position).getSub());
        convertView .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent studIntent = new Intent(context,HomeworkActivity.class);
                studIntent.putExtra("id",hwnurserydisplay.obj.get(position).getId());
                studIntent.putExtra("position",""+position);
                studIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(studIntent);
            }
        });
        final View finalConvertView = convertView;
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(finalConvertView.getRootView().getContext());
                dialog.setMessage("Delete Record");
                dialog.setTitle("Deleting Homework");
                dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        RequestQueue q = Volley.newRequestQueue(context);
                        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Homeworkdelete.php?id="+hwnurserydisplay.obj.get(position).getId(), new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                if (response.length() > 0) {
                                    try {
                                        JSONObject obj = response.getJSONObject(0);
                                        String msg = obj.getString("msg");
                                        if (msg.equalsIgnoreCase("Deleted")) {
                                            hwnurserydisplay.obj.remove(position);
                                            notifyDataSetChanged();
                                            Toast.makeText(context, "Data deleted", Toast.LENGTH_LONG).show();
                                        } else {
                                            Toast.makeText(context, "Not Deleted", Toast.LENGTH_LONG).show();
                                        }
                                    } catch (Exception e) {

                                    }
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                            }
                        });
                        q.add(req);
                    }
                });
                dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"Record delete Canceled",Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog alert=dialog.create();
                alert.show();
                return true;
            }
        });





        return convertView;
    }
}

