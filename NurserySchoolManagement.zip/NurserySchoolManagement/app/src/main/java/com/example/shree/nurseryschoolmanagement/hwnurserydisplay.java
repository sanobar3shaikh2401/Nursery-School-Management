package com.example.shree.nurseryschoolmanagement;

import java.util.ArrayList;

public class hwnurserydisplay {
    String date,hw,tid,sub,Id;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getHw() {
        return hw;
    }

    public void setHw(String hw) {
        this.hw = hw;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public static ArrayList<hwnurserydisplay> obj=new ArrayList<hwnurserydisplay>();
}
