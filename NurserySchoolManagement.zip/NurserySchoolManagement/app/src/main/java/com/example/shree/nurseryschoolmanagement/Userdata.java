package com.example.shree.nurseryschoolmanagement;

public class Userdata {
  public static String id,name,add,phno,email,unm,pass;

}
