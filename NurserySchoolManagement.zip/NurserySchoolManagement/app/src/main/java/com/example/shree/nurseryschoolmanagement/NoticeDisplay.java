package com.example.shree.nurseryschoolmanagement;

import java.util.ArrayList;

public class NoticeDisplay {
    String dt,cls,desc,sub,id;
    boolean checklist=false;

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public String getCls() {
        return cls;
    }

    public void setCls(String cls) {
        this.cls = cls;
    }

    public String getDesc() {
        return desc;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }


    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public static ArrayList<NoticeDisplay> arr = new ArrayList<NoticeDisplay>();

}
