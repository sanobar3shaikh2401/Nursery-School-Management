package com.example.shree.nurseryschoolmanagement;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class NoticeAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflater;
    public NoticeAdapter(Context context){
        this.context=context;
    }
    @Override
    public int getCount() {
        return NoticeDisplay.arr.size();
    }

    @Override
    public Object getItem(int position) {
        return NoticeDisplay.arr.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return NoticeDisplay.arr.size();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(R.layout.noticeadapter,null);
        NoticeDisplay details = getDisplay(position);
        TextView t1 =(TextView) convertView.findViewById(R.id.txt_dt);
        TextView t2 =(TextView) convertView.findViewById(R.id.txt_cls);
        TextView t3 =(TextView) convertView.findViewById(R.id.txt_desc);
        TextView t4=(TextView) convertView.findViewById(R.id.txt_sub);
        CheckBox chk = (CheckBox) convertView.findViewById(R.id.chk_delete);
        t1.setText(NoticeDisplay.arr.get(position).getDt());
        t2.setText(NoticeDisplay.arr.get(position).getCls());
        t3.setText(NoticeDisplay.arr.get(position).getDesc());
        t4.setText(NoticeDisplay.arr.get(position).getSub());
        chk.setOnCheckedChangeListener(mycheckList);
        chk.setTag(position);
        chk.setChecked(details.checklist);
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent studIntent = new Intent(context,NoticeActivity.class);
                studIntent.putExtra("id",NoticeDisplay.arr.get(position).getId());
                studIntent.putExtra("position",""+position);
                studIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(studIntent);
            }
        });
        final View finalConvertView = convertView;
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(finalConvertView.getRootView().getContext());
                dialog.setMessage("Delete Record");
                dialog.setTitle("Deleting Notice");
                dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        RequestQueue q = Volley.newRequestQueue(context);
                        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Noticedelete.php?id="+NoticeDisplay.arr.get(position).getId(), new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                if (response.length() > 0) {
                                    try {
                                        JSONObject obj = response.getJSONObject(0);
                                        String msg = obj.getString("msg");
                                        if (msg.equalsIgnoreCase("Deleted")) {
                                            NoticeDisplay.arr.remove(position);
                                            notifyDataSetChanged();
                                            Toast.makeText(context, "Data deleted", Toast.LENGTH_LONG).show();
                                        } else {
                                            Toast.makeText(context, "Not Deleted", Toast.LENGTH_LONG).show();
                                        }
                                    } catch (Exception e) {

                                    }
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                            }
                        });
                        q.add(req);
                    }
                });
                dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"Record delete Canceled",Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog alert=dialog.create();
                alert.show();
                return true;
            }
        });


        return convertView;

    }
    NoticeDisplay getDisplay(int ps){
        return((NoticeDisplay)getItem(ps));


    }
    public  static ArrayList<NoticeDisplay> getbox(){
        ArrayList<NoticeDisplay> b=new ArrayList<NoticeDisplay>();
        for(NoticeDisplay c: NoticeDisplay.arr){
            if (c.checklist){
                b.add(c);
            }
        }
        return b;
    }
    CompoundButton.OnCheckedChangeListener mycheckList = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            getDisplay((Integer) buttonView.getTag()).checklist = isChecked;
        }
    };
    /**/
}
