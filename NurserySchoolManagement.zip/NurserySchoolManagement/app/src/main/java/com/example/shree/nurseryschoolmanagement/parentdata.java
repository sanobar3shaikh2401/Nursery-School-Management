package com.example.shree.nurseryschoolmanagement;

public class parentdata {
    public static String rn,nm,add,phno,cls,email,doa;
}
