package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

public class HomeworkActivity extends AppCompatActivity {
    Spinner spnr_std;
    EditText e1,e2,e3,e4;
    Button b1;
    DatePicker dp;
    String id=null;
    int position;

    String std[]={"SELECT CLASS","Nursery","LKG","UKG"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homework);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        e1 = (EditText) findViewById(R.id.edt_sub);
        e2 = (EditText) findViewById(R.id.edt_desp);
        e3 = (EditText) findViewById(R.id.edt_tid);
        e4 = (EditText) findViewById(R.id.edt_id);
        b1 = (Button) findViewById(R.id.btn_send);
        dp = (DatePicker) findViewById(R.id._date);
        spnr_std = (Spinner) findViewById(R.id.spnr_std);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_item, std);
        spnr_std.setAdapter(adapter1);

        try {
            Intent tmp = getIntent();
            id = tmp.getStringExtra("id");
            position = Integer.parseInt(tmp.getStringExtra("position"));
            fetchStudInfo();
        } catch (Exception e) {

        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (id == null) {
                    RequestQueue q = Volley.newRequestQueue(getApplicationContext());
                    JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/Homeworkinsert.php?Date=12-1-19&Homework=" + e2.getText().toString() + "&Teacherid=" + e3.getText().toString() + "&Subject=" + e1.getText().toString() + "&Class=" + spnr_std.getSelectedItem().toString(), new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Data inserted")) {
                                        Toast.makeText(getApplicationContext(), "Inserted", Toast.LENGTH_LONG).show();
                                        finish();
                                    } else {
                                        Toast.makeText(getApplicationContext(), "Not inserted", Toast.LENGTH_LONG).show();
                                    }
                                } catch (Exception e) {

                                }
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    });
                    q.add(req);

                } else {
                    RequestQueue q = Volley.newRequestQueue(getApplicationContext());
                    String url="http://192.168.43.211/NSM/Homeworkupdate.php?id="+id+"&date=12-1-19"+"&hw=" + e2.getText().toString() + "&tid=" + e3.getText().toString() + "&sub=" + e1.getText().toString() + "&class=" + spnr_std.getSelectedItem().toString();
                    JsonArrayRequest req = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Updated")) {
                                        Toast.makeText(getApplicationContext(), "Updated", Toast.LENGTH_LONG).show();
                                        Homeworkdisplay.obj.get(position).setSub(e1.getText().toString());
                                        Homeworkdisplay.obj.get(position).setHw(e2.getText().toString());
                                        Homeworkdisplay.obj.get(position).setTid(e3.getText().toString());


                                        finish();
                                    } else {
                                        Toast.makeText(getApplicationContext(), "not Updated", Toast.LENGTH_LONG).show();

                                    }
                                } catch (Exception e) {

                                }

                            }
                        }

                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                    q.add(req);
                }
            }});
    }
    private void fetchStudInfo() {
        RequestQueue q= Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest req=new JsonArrayRequest("http://192.168.43.211/NSM/Homeworkdisplay.php?id="+id,new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int count = response.length();
                //Studisplay.obj.clear();
                for (int i = 0; i < count; i++) {
                    try {

                        JSONObject obj = response.getJSONObject(i);
                        Homeworkdisplay s = new Homeworkdisplay();
                        e4.setText(obj.getString("id"));
                        e2.setText(obj.getString("Homework"));
                        e3.setText(obj.getString("Teacherid"));
                        e1.setText(obj.getString("Subject"));

                        Homeworkdisplay.obj.add(s);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }


            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        );
        q.add(req);
    }






           @Override
           public boolean onSupportNavigateUp() {
               finish();
               return super.onSupportNavigateUp();
           }
       }