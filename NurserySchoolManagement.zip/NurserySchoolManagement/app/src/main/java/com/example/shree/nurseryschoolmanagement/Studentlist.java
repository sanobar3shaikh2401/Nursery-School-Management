package com.example.shree.nurseryschoolmanagement;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class Studentlist extends FragmentStatePagerAdapter {
    int count;
    String[] title = {"Nursary","LKG","UKG"};
    public Studentlist(FragmentManager fm,int count) {
        super(fm);
        this.count=count;

    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return title[position];
    }

    @Override
        public Fragment getItem ( int position){
        switch (position) {
            case 0:
                Nursuryfrag nur = new Nursuryfrag();

                return nur;
            case 1:
                LKGfrag lkg = new LKGfrag();

                return lkg;
            case 2:
                UKGfrag ukg = new UKGfrag();
                return ukg;
        }
            return null;
        }

        @Override
        public int getCount () {
            return count;
        }


}
