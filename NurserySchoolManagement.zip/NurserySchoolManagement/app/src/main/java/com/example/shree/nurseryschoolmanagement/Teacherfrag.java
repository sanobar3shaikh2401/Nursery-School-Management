package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class Teacherfrag extends Fragment {
    View view;
    ListView l1;
    ArrayList<TeacherDisp> data;
    TeacherAdapter tadp;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.teacherfrag,null);
        l1=(ListView) view.findViewById(R.id.lst_teach);
        RequestQueue queue = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/teacherdisplay.php", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                TeacherDisp.obj.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        TeacherDisp t = new TeacherDisp();
                        t.setId(jobj.getString("ID"));
                        t.setNm(jobj.getString("Name"));
                        t.setAdd(jobj.getString("Address"));
                        t.setPh(jobj.getString("Phone_no"));
                        t.setEmail(jobj.getString("Email"));
                        t.setUnm(jobj.getString("Username"));
                        t.setPass(jobj.getString("Password"));
                        TeacherDisp.obj.add(t);
                       // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                TeacherAdapter tadp = new TeacherAdapter(getActivity().getApplicationContext());
                l1.setAdapter(tadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue.add(req);
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                Intent std=new Intent(getActivity().getApplicationContext(),TeacherActivity.class);
                startActivity(std);

            }
        });
        FloatingActionButton fab1= (FloatingActionButton) view.findViewById(R.id.fab1);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                //      .setAction("Action", null).show();
                data = TeacherAdapter.getbox();
                for (int i = 0; i < data.size(); i++) {
                    final int finali = i;

                    RequestQueue q = Volley.newRequestQueue(getActivity().getApplicationContext());
                    JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/teacherdelete.php?id=" + TeacherDisp.obj.get(i).getId(), new Response.Listener<JSONArray>() {
                        @Override
                        public void onResponse(JSONArray response) {
                            if (response.length() > 0) {
                                try {
                                    JSONObject obj = response.getJSONObject(0);
                                    String msg = obj.getString("msg");
                                    if (msg.equalsIgnoreCase("Deleted")) {
                                        TeacherDisp.obj.remove(finali);
                                        //notifyDataSetChanged();
                                        Toast.makeText(getActivity().getApplicationContext(), "Data deleted", Toast.LENGTH_LONG).show();
                                    } else {
                                        Toast.makeText(getActivity().getApplicationContext(), "Not Deleted", Toast.LENGTH_LONG).show();
                                    }
                                } catch (Exception e) {

                                }
                            }

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                        }
                    });

                    q.add(req);
                }

//                tadp.notifyDataSetChanged();


            }
        });

                    return view;
        }


    @Override
    public void onResume() {


        super.onResume();
        RequestQueue queue1 = Volley.newRequestQueue(getActivity().getApplicationContext());
        JsonArrayRequest req1 = new JsonArrayRequest("http://192.168.43.211/NSM/teacherdisplay.php", new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                int cnt=response.length();
                TeacherDisp.obj.clear();
                for (int i=0;i<cnt;i++) {
                    try {
                        JSONObject jobj = response.getJSONObject(i);
                        TeacherDisp t = new TeacherDisp();
                        t.setId(jobj.getString("ID"));
                        t.setNm(jobj.getString("Name"));
                        t.setAdd(jobj.getString("Address"));
                        t.setPh(jobj.getString("Phone_no"));
                        t.setEmail(jobj.getString("Email"));
                        t.setUnm(jobj.getString("Username"));
                        t.setPass(jobj.getString("Password"));
                        TeacherDisp.obj.add(t);
                        // t.setId(jobj.getString("ID"));
                    }catch (Exception e){
                        Toast.makeText(getActivity().getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }
                TeacherAdapter tadp = new TeacherAdapter(getActivity().getApplicationContext());
                l1.setAdapter(tadp);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        queue1.add(req1);
                }

            }
