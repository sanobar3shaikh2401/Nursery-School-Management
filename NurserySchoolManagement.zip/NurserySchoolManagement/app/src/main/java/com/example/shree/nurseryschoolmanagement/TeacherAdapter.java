package com.example.shree.nurseryschoolmanagement;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class TeacherAdapter extends BaseAdapter {
    Context context;
    LayoutInflater inflate;
    public TeacherAdapter(Context context){
        this.context=context;
    }
    @Override
    public int getCount() {
        return TeacherDisp.obj.size();
    }

    @Override
    public Object getItem(int position) {
        return TeacherDisp.obj.get(position);
    }

    @Override
    public int getViewTypeCount() {
        return TeacherDisp.obj.size();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        inflate = LayoutInflater.from(context);
        convertView = inflate.inflate(R.layout.teacherdisp,null);
        TeacherDisp details = getDisplay(position);
        TextView t1 =(TextView) convertView.findViewById(R.id.txt_id);
        TextView t2 =(TextView) convertView.findViewById(R.id.txt_nm);
        TextView t3 =(TextView) convertView.findViewById(R.id.txt_add);
        TextView t4 =(TextView) convertView.findViewById(R.id.txt_ph);
        TextView t5 =(TextView) convertView.findViewById(R.id.txt_email);
        TextView t6 =(TextView) convertView.findViewById(R.id.txt_unm);
        TextView t7 =(TextView) convertView.findViewById(R.id.txt_pass);
        CheckBox chk = (CheckBox) convertView.findViewById(R.id.chk_delete);
        t1.setText(TeacherDisp.obj.get(position).getId());
        t2.setText(TeacherDisp.obj.get(position).getNm());
        t3.setText(TeacherDisp.obj.get(position).getAdd());
        t4.setText(TeacherDisp.obj.get(position).getPh());
        t5.setText(TeacherDisp.obj.get(position).getEmail());
        t6.setText(TeacherDisp.obj.get(position).getUnm());
        t7.setText(TeacherDisp.obj.get(position).getPass());
        chk.setOnCheckedChangeListener(mycheckList);
        chk.setTag(position);
        chk.setChecked(details.checklist);
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent studIntent = new Intent(context,TeacherActivity.class);
                studIntent.putExtra("id",TeacherDisp.obj.get(position).getId());
                studIntent.putExtra("position",""+position);
                studIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(studIntent);
            }
        });
        final View finalConvertView = convertView;
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(finalConvertView.getRootView().getContext());
                dialog.setMessage("Delete Record");
                dialog.setTitle("Deleting Teacher");
                dialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        RequestQueue q = Volley.newRequestQueue(context);
                        JsonArrayRequest req = new JsonArrayRequest("http://192.168.43.211/NSM/teacherdelete.php?id="+TeacherDisp.obj.get(position).getId(), new Response.Listener<JSONArray>() {
                            @Override
                            public void onResponse(JSONArray response) {
                                if (response.length() > 0) {
                                    try {
                                        JSONObject obj = response.getJSONObject(0);
                                        String msg = obj.getString("msg");
                                        if (msg.equalsIgnoreCase("Deleted")) {
                                            TeacherDisp.obj.remove(position);
                                            notifyDataSetChanged();
                                            Toast.makeText(context, "Data deleted", Toast.LENGTH_LONG).show();
                                        } else {
                                            Toast.makeText(context, "Not Deleted", Toast.LENGTH_LONG).show();
                                        }
                                    } catch (Exception e) {

                                    }
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                            }
                        });
                        q.add(req);
                    }
                });
                dialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(context,"Record delete Canceled",Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog alert=dialog.create();
                alert.show();
                return true;
            }
        });





        return convertView;
    }

    TeacherDisp getDisplay(int ps){
        return((TeacherDisp)getItem(ps));


    }
    public  static ArrayList<TeacherDisp> getbox(){
        ArrayList<TeacherDisp> b=new ArrayList<TeacherDisp>();
        for(TeacherDisp c: TeacherDisp.obj){
            if (c.checklist){
                b.add(c);
            }
        }
        return b;
    }
    CompoundButton.OnCheckedChangeListener mycheckList = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            getDisplay((Integer) buttonView.getTag()).checklist = isChecked;
        }
    };
    /**/
}