package com.example.shree.nurseryschoolmanagement;

import java.util.ArrayList;

public class TeacherDisp {
    String nm,id,unm,pass,add,ph,email;
    boolean checklist=false;

    public String getNm() {
        return nm;

    }

    public void setNm(String nm) {
        this.nm = nm;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getUnm() {
        return unm;
    }

    public void setUnm(String unm) {
        this.unm = unm;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPh() {
        return ph;
    }

    public void setPh(String ph) {
        this.ph = ph;
    }
    public static ArrayList<TeacherDisp> obj = new ArrayList<TeacherDisp>();
}
