package com.example.shree.nurseryschoolmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

public class ParentActivity extends AppCompatActivity {

    private TextView mTextMessage;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            FragmentManager fm=getSupportFragmentManager();
            FragmentTransaction ft=fm.beginTransaction();
            ft.add(R.id.parent,new hwkfrag());
            switch (item.getItemId()) {
                case R.id.nav_hmwk:
                    ft.replace(R.id.parent,new hwkfrag());
                    ft.commit();
                    return true;
                case R.id.nav_eve:
                    ft.replace(R.id.parent,new Evefrag());
                    ft.commit();
                    return true;
                case R.id.nav_not:
                    ft.replace(R.id.parent,new Notfrag());
                    ft.commit();
                    return true;
                case R.id.nav_info:
                    ft.replace(R.id.parent,new Infofrag());
                    ft.commit();
                    return true;

            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        ft.add(R.id.parent,new hwkfrag());
        ft.commit();
    }

    @Override
    public boolean onSupportNavigateUp() {
            finish();
        return super.onSupportNavigateUp();
    }

}
